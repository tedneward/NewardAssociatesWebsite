/**
 * Compiled this into the "C:\Prg\JDK1.2.2\JRE\classes" directory, or
 * wherever your JRE lives
 */
public class NewObject
{
}
