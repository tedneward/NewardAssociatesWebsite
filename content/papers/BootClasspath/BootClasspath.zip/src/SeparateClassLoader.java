import java.io.*;
import java.net.*;

public class SeparateClassLoader
{
    public static void main (String args[]) 
        throws Exception
    {
        // Create a URLClassLoader that uses as its parent
        // ClassLoader the bootstrap ClassLoader (indicated
        // by the "null" URLClassLoader constructor's 
        // second argument value). This means that this
        // ClassLoader no longer uses the AppClassLoader and
        // ExtClassLoader as parent delegates, and should
        // not pick up code along the CLASSPATH (such as the
        // current directory).
        //
        URL[] urlArray = 
        {
            new File("./nonexistent_directory").toURL()
        };
        URLClassLoader cl = new URLClassLoader(urlArray, null);
        cl.loadClass(SeparateClassLoader.class.getName());
        
    }
}
