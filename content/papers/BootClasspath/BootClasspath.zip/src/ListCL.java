public class ListCL {
    public static void main (String args[]) {
        System.out.println(java.lang.Object.class.getClassLoader());
    }
}
