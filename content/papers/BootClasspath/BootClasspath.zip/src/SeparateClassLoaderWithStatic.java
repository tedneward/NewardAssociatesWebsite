import java.io.*;
import java.net.*;

public class SeparateClassLoaderWithStatic
{
    public static int instanceCount = 0;

    public SeparateClassLoaderWithStatic()
    {
        System.out.println("This is instance #" + ++instanceCount);
    }

    public static void main (String args[]) 
        throws Exception
    {
        new SeparateClassLoaderWithStatic();

        // Create a URLClassLoader that uses as its parent
        // ClassLoader the bootstrap ClassLoader (indicated
        // by the "null" URLClassLoader constructor's 
        // second argument value). This means that this
        // ClassLoader no longer uses the AppClassLoader and
        // ExtClassLoader as parent delegates, and should
        // not pick up code along the CLASSPATH (such as the
        // current directory).
        //
        URL[] urlArray = 
        {
            new File(System.getProperty("user.dir")).toURL()
        };
        URLClassLoader cl = new URLClassLoader(urlArray, null);
        cl.loadClass("SeparateClassLoaderWithStatic").newInstance();
    }
}
