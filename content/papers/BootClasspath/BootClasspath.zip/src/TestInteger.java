public class TestInteger {
    public static void main (String args[]) {
        new Integer(12);
    }
}
