public class Props {
    public static void main (String args[]) {
        //System.getProperties().list(System.out);
        System.out.println(System.getProperty("sun.boot.class.path"));
    }
}
