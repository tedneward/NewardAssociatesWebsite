/**
 * Compile and run anywhere, without the JRE\classes directory
 * on the CLASSPATH (NewObject.class must be in the JRE\classes directory)
 */
public class NewObjectLoader {
    public static void main (String args[]) {
        NewObject no = new NewObject();
        System.out.println(
            no.getClass().getName() + " was loaded by " +
            no.getClass().getClassLoader());
    }
}
