public class One 
{
    public One()
    {
        System.out.println("One constructed");
    }
}
