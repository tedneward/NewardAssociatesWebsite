public class VersionOne 
{
    static
    {
        Versions.registerClass(VersionOne.class, "$Logfile: $ $Revsion: $");
    }

    public VersionOne()
    {
        System.out.println("VersionOne constructed");
    }
}
