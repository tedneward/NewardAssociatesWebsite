public class VersionMain
{
    static
    {
        Versions.registerClass(VersionMain.class, "$Logfile: $ $Revsion: $");
    }

    public static void main (String args[]) 
    {
        System.out.println("VersionMain");

        System.out.println("Built using:");
        for (java.util.Iterator i = Versions.classes(); i.hasNext(); ) 
        {
            Class c = (Class)i.next();
            System.out.println(c + " -- " + Versions.classInfo(c));
        }

        VersionOne v1 = new VersionOne();
        VersionTwo v2 = new VersionTwo();
    
        System.out.println("Built using:");
        for (java.util.Iterator i = Versions.classes(); i.hasNext(); ) 
        {
            Class c = (Class)i.next();
            System.out.println(c + " -- " + Versions.classInfo(c));
        }
    }
}
