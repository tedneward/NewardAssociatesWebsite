public class VersionTwo
{
    static
    {
        Versions.registerClass(VersionTwo.class, "$Logfile: $ $Revsion: $");
    }

    public VersionTwo()
    {
        System.out.println("VersionTwo constructed");
    }
}
