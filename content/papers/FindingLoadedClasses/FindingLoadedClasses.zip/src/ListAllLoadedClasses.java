import java.util.*;

public class ListAllLoadedClasses 
{
    public static final String RCSINFO = "Put Versioning info here";

    // Given an Iterator from ListAllLoadedClasses.list(), find the
    // RCSINFO String, if present
    //
    public static String extractRCSInfo(Class c)
    {
        try
        {
            java.lang.reflect.Field RCSINFO_field = c.getDeclaredField("RCSINFO");
            return (String)RCSINFO_field.get(null);
        }
        catch (NoSuchFieldException nsfEx)
        {
            return "<<no versioning info found>>";
        }
        catch (IllegalAccessException iaEx)
        {
            return "<<no versioning info found>>";
        }
    }
    public static Iterator list(ClassLoader CL)
        throws NoSuchFieldException, IllegalAccessException
    {
        Class CL_class = CL.getClass();
        while (CL_class != java.lang.ClassLoader.class) 
        {
            CL_class = CL_class.getSuperclass();
        }

        java.lang.reflect.Field ClassLoader_classes_field =
            CL_class.getDeclaredField("classes");
        ClassLoader_classes_field.setAccessible(true);

        Vector classes = (Vector)ClassLoader_classes_field.get(CL);
        return classes.iterator();
    }

    public static void main (String args[]) 
        throws Exception
    {
        One one = new One();
        Two two = new Two();

        ClassLoader myCL = ListAllLoadedClasses.class.getClassLoader();

        while (myCL != null) 
        {
            System.out.println("ClassLoader: " + myCL);
            for (Iterator iter = list(myCL); iter.hasNext(); ) 
            {
                Class c = (Class)iter.next();
                System.out.println("\t" + c + "(" + extractRCSInfo(c) + ")");
            }

            myCL = myCL.getParent();
        }
    }
}
