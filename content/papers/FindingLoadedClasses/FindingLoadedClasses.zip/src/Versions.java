import java.util.*;

public class Versions
{
    private static Map classMap = new HashMap();
    public static void registerClass(Class c, String rcsInfo)
    {
        classMap.put(c, rcsInfo);
    }
    public static Iterator classes()
    {
        return classMap.keySet().iterator();
    }
    public static String classInfo(Class c)
    {
        return (String)classMap.get(c);
    }
}

