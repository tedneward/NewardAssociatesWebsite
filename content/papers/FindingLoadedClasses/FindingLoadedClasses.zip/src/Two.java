public class Two 
{
    public Two()
    {
        System.out.println("Two constructed");
    }
}
