#include <stdio.h>

// Prototypes from one.c
void one();
// Prototypes from two.c
void two();

static char rcsInfo[] = "RCS: main.c, Version 1.0";
   
int main(int argc, char* argv[])
{
   one();
   two();
}
