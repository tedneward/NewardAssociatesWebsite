#include <stdio.h>

static char rcsInfo[] = "RCS: one.c, Version 1.0";

void one()
{
   printf("one called\n");
}
