#include <stdio.h>

static char rcsInfo[] = "RCS: two.c, Version 2.0";

void two()
{
   printf("two called one more time\n");
}
