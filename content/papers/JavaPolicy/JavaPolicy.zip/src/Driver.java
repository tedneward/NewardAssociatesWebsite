import java.io.*;

public class Driver
{
    /**
     * Test driver
     */
    public static void main (String args[])
        throws Exception
    {
        try
        {
            // Now try to do something
            //
            FileInputStream fis = new FileInputStream("test.file");
            int ch;
            while ((ch = fis.read()) != -1) 
            {
                System.out.write(ch);
            }
            System.out.println("");
        }
        catch (SecurityException secEx)
        {
            secEx.printStackTrace();
        }

        // Force a refresh, which for our policy causes everything
        // to be allowed from now on.
        //
        java.security.Policy.getPolicy().refresh();

        try
        {
            // Now try to do something
            //
            FileInputStream fis = new FileInputStream("test.file");
            int ch;
            while ((ch = fis.read()) != -1) 
            {
                System.out.write(ch);
            }
            System.out.println("");
        }
        catch (SecurityException secEx)
        {
            secEx.printStackTrace();
        }
    }
}
