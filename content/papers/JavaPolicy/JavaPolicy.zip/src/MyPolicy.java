package com.javageeks.security;

import java.security.*;
import java.util.*;

/**
 *
 */
class MyPermission extends BasicPermission
{
    static boolean allow;

    public MyPermission()
    {
        super("<<custom permission>>");
    }

    public boolean implies(Permission p)
    {
        System.out.println("<<" + getClass() + ".implies(" + p + ") called>>");

        // Special-case permissions always on
        //
        if (p instanceof SecurityPermission) 
        {
            return true;
        }

        return allow;
    }
}

/**
 *
 */
class MyPermissionCollection extends PermissionCollection
{
    ArrayList perms = new ArrayList();

    public void add(Permission p)
    {
        perms.add(p);
    }
    public boolean implies(Permission p)
    {
        System.out.println("<<PermissionCollection.implies(" + p + ") called>>");
        for (Iterator i = perms.iterator(); i.hasNext(); ) 
        {
            if (((Permission)i.next()).implies(p)) 
            {
                return true;
            }
        }
        return false;
    }
    public Enumeration elements()
    {
        return null;
    }
    public void setReadOnly()
    {
    }
    public boolean isReadOnly()
    {
        return false;
    }
    public String toString()
    {
        return super.toString();
    }
}

/**
 *
 */
public class MyPolicy extends Policy
{
    private static PermissionCollection perms;
    
    static
    {
        System.out.println("<<MyPolicy loaded>>");
    }

    public MyPolicy()
    {
        System.out.println("<<MyPolicy constructed>>");

        if (perms == null) 
        {
            perms = new MyPermissionCollection();
            perms.add(new MyPermission());
        }
    }

    /**
     * Evaluates the global policy and returns a
     * PermissionCollection object specifying the set of
     * permissions allowed for code from the specified
     * code source.
     *
     * @param codesource the CodeSource associated with the caller.
     * This encapsulates the original location of the code (where the code
     * came from) and the public key(s) of its signer.
     *
     * @return the set of permissions allowed for code from <i>codesource</i>
     * according to the policy.
     *
     * @exception java.lang.SecurityException if the current thread does not
     *            have permission to call <code>getPermissions</code> on the policy object.

     */
    public PermissionCollection getPermissions(CodeSource codesource)
    {
        System.out.println("<<getPermissions called for '" + codesource + "'>>");
        return perms;
    }

    /**
     * Refreshes/reloads the policy configuration. The behavior of this method
     * depends on the implementation. For example, calling <code>refresh</code>
     * on a file-based policy will cause the file to be re-read.
      *
     * @exception java.lang.SecurityException if the current thread does not
     *            have permission to refresh this Policy object.
     */
    public void refresh()
    {
        System.out.println("<<refresh called>>");
        MyPermission.allow = true;
    }
}
