/**
 * Simple class that just prints the number of instances that have been
 * created thus far.
 */
public class Dummy
{
    public static int staticCount = 0;

    public Dummy()
    {
        staticCount++;
        System.out.println("Instance #" + staticCount + " constructed.");
    }
}

