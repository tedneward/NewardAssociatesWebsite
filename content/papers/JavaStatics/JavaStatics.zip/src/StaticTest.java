import java.io.*;
import java.net.*;

/**
 * Simple test--instantiate three Dummy objects, and watch the staticCount
 * static field get incremented, as we would expect.
 */
public class StaticTest
{
    public static void main (String args[])
        throws Exception
    {
        new Dummy();
        new Dummy();
        new Dummy();
    }
}
