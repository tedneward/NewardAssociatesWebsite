import java.io.*;
import java.net.*;

/**
 * Load the same class (with statics) into two separate ClassLoaders.
 * See what the class' reported static count is.
 */
public class StaticTestClassLoader
{
    public static void main (String args[])
        throws Exception
    {
        URL[] url = { new File("subdir").toURL() };

        URLClassLoader cl1 = new URLClassLoader(url);
        URLClassLoader cl2 = new URLClassLoader(url);
        URLClassLoader cl3 = new URLClassLoader(url);

        cl1.loadClass("Dummy").newInstance();
        cl2.loadClass("Dummy").newInstance();
        cl3.loadClass("Dummy").newInstance();
    }
}
